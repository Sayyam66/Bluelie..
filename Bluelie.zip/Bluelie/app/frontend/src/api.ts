const BASE_URL = process.env.EXPO_PUBLIC_BACKEND_URL;

export interface BirthDetails {
  name: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  latitude: number;
  longitude: number;
  tz_offset: number;
  place?: string;
}

export interface PlanetPosition {
  name: string;
  name_hi: string;
  longitude: number;
  longitude_formatted: string;
  rashi: string;
  rashi_hi: string;
  house: number;
  nakshatra: string;
  nakshatra_hi: string;
  pada: number;
  retrograde: boolean;
}

export interface HouseSign {
  house: number;
  sign_index: number;
  sign: string;
  sign_hi: string;
  planets: string[];
}

export interface KundliResponse {
  name: string;
  birth_datetime: string;
  place: string;
  lagna: string;
  lagna_hi: string;
  lagna_lord: string;
  moon_rashi: string;
  moon_rashi_hi: string;
  moon_nakshatra: string;
  moon_nakshatra_hi: string;
  moon_pada: number;
  nakshatra_lord: string;
  sun_rashi: string;
  sun_rashi_hi: string;
  planets: PlanetPosition[];
  house_signs: HouseSign[];
}

export interface KootScore {
  name: string;
  name_hi: string;
  max_points: number;
  obtained: number;
  description: string;
}

export interface MatchResponse {
  boy_name: string;
  girl_name: string;
  boy_rashi: string;
  boy_nakshatra: string;
  girl_rashi: string;
  girl_nakshatra: string;
  total_score: number;
  max_score: number;
  percentage: number;
  verdict: string;
  verdict_hi: string;
  koots: KootScore[];
}

export interface PlaceInfo {
  name: string;
  lat: number;
  lon: number;
  tz: number;
}

export async function generateKundli(details: BirthDetails): Promise<KundliResponse> {
  const res = await fetch(`${BASE_URL}/api/kundli/generate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(details),
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(t || "Failed to generate kundli");
  }
  return res.json();
}

export async function matchKundli(boy: BirthDetails, girl: BirthDetails): Promise<MatchResponse> {
  const res = await fetch(`${BASE_URL}/api/kundli/match`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ boy, girl }),
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(t || "Failed to match kundli");
  }
  return res.json();
}

export async function searchPlaces(q: string): Promise<PlaceInfo[]> {
  const res = await fetch(`${BASE_URL}/api/places?q=${encodeURIComponent(q)}`);
  if (!res.ok) return [];
  return res.json();
}

export async function getAllPlaces(): Promise<PlaceInfo[]> {
  const res = await fetch(`${BASE_URL}/api/places`);
  if (!res.ok) return [];
  return res.json();
}

import React, { useState } from "react";
import { View, Text, Pressable, StyleSheet, Modal, Platform } from "react-native";
import DateTimePicker from "@react-native-community/datetimepicker";
import { Feather } from "@expo/vector-icons";
import { colors, spacing, radius } from "../theme";

interface Props {
  mode: "date" | "time";
  value: string; // formatted string
  onChange: (formatted: string) => void;
  testID?: string;
  label: string;
}

function pad(n: number) {
  return n < 10 ? `0${n}` : `${n}`;
}

function formatDate(d: Date) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function formatTime(d: Date) {
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function parseInitial(mode: "date" | "time", value: string): Date {
  const d = new Date();
  if (!value) {
    if (mode === "date") d.setFullYear(1995, 0, 1);
    else d.setHours(8, 30, 0, 0);
    return d;
  }
  if (mode === "date") {
    const parts = value.split(/[-/.]/);
    if (parts.length === 3) {
      let y: number, m: number, day: number;
      if (parts[0].length === 4) {
        y = parseInt(parts[0], 10); m = parseInt(parts[1], 10) - 1; day = parseInt(parts[2], 10);
      } else {
        // DD/MM/YYYY
        day = parseInt(parts[0], 10); m = parseInt(parts[1], 10) - 1; y = parseInt(parts[2], 10);
      }
      if (!isNaN(y) && !isNaN(m) && !isNaN(day)) {
        d.setFullYear(y, m, day);
      }
    }
  } else {
    const parts = value.split(":");
    const hh = parseInt(parts[0] || "8", 10);
    const mm = parseInt(parts[1] || "30", 10);
    if (!isNaN(hh) && !isNaN(mm)) d.setHours(hh, mm, 0, 0);
  }
  return d;
}

export default function DateTimeField({ mode, value, onChange, testID, label }: Props) {
  const [show, setShow] = useState(false);
  const [tempDate, setTempDate] = useState<Date>(() => parseInitial(mode, value));

  const displayValue = value || (mode === "date" ? "Select date" : "Select time");

  // Web fallback using plain HTML input via a hidden element is not straightforward
  // in RN Web. We instead show a small custom overlay with the native picker.
  const openPicker = () => {
    setTempDate(parseInitial(mode, value));
    setShow(true);
  };

  const confirmIOS = () => {
    onChange(mode === "date" ? formatDate(tempDate) : formatTime(tempDate));
    setShow(false);
  };

  return (
    <View>
      <Text style={styles.label}>{label}</Text>
      <Pressable testID={testID} onPress={openPicker} style={styles.field}>
        <Text style={value ? styles.value : styles.placeholder}>{displayValue}</Text>
        <Feather name={mode === "date" ? "calendar" : "clock"} size={16} color={colors.muted} />
      </Pressable>

      {/* Android: opens modal picker directly */}
      {show && Platform.OS === "android" && (
        <DateTimePicker
          value={tempDate}
          mode={mode}
          is24Hour={true}
          onChange={(_e, d) => {
            setShow(false);
            if (d) onChange(mode === "date" ? formatDate(d) : formatTime(d));
          }}
        />
      )}

      {/* iOS: modal with spinner + confirm */}
      {Platform.OS === "ios" && (
        <Modal transparent visible={show} animationType="slide" onRequestClose={() => setShow(false)}>
          <View style={styles.iosOverlay}>
            <View style={styles.iosSheet}>
              <View style={styles.iosHeader}>
                <Pressable onPress={() => setShow(false)}>
                  <Text style={styles.iosCancel}>Cancel</Text>
                </Pressable>
                <Pressable onPress={confirmIOS} testID={`${testID}-confirm`}>
                  <Text style={styles.iosDone}>Done</Text>
                </Pressable>
              </View>
              <DateTimePicker
                value={tempDate}
                mode={mode}
                display="spinner"
                is24Hour={true}
                onChange={(_e, d) => d && setTempDate(d)}
              />
            </View>
          </View>
        </Modal>
      )}

      {/* Web: use a hidden native input via createElement */}
      {show && Platform.OS === "web" && (
        <WebNativeInput
          mode={mode}
          value={value}
          onCommit={(v) => { onChange(v); setShow(false); }}
          onClose={() => setShow(false)}
        />
      )}
    </View>
  );
}

function WebNativeInput({
  mode,
  value,
  onCommit,
  onClose,
}: {
  mode: "date" | "time";
  value: string;
  onCommit: (v: string) => void;
  onClose: () => void;
}) {
  const [v, setV] = useState(value);
  // Convert legacy DD/MM/YYYY to YYYY-MM-DD for input
  const initial = React.useMemo(() => {
    if (mode !== "date") return value;
    if (!value) return "";
    if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
    const parts = value.split(/[/\-\.]/);
    if (parts.length === 3 && parts[2].length === 4) {
      return `${parts[2]}-${parts[1].padStart(2, "0")}-${parts[0].padStart(2, "0")}`;
    }
    return "";
  }, [value, mode]);

  return (
    <Modal transparent visible animationType="fade" onRequestClose={onClose}>
      <View style={styles.iosOverlay}>
        <View style={styles.iosSheet}>
          <View style={styles.iosHeader}>
            <Pressable onPress={onClose}><Text style={styles.iosCancel}>Cancel</Text></Pressable>
            <Text style={styles.webTitle}>{mode === "date" ? "Select Date" : "Select Time"}</Text>
            <Pressable onPress={() => onCommit(v || initial)}><Text style={styles.iosDone}>Done</Text></Pressable>
          </View>
          <View style={{ padding: spacing.lg, alignItems: "center" }}>
            {React.createElement("input", {
              type: mode,
              defaultValue: initial,
              onChange: (e: any) => setV(e.target.value),
              style: {
                fontSize: 22,
                padding: 12,
                border: `1px solid ${colors.border}`,
                borderRadius: 8,
                background: colors.surface,
                color: colors.onSurface,
                fontFamily: "System",
              },
            })}
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  label: {
    fontSize: 12,
    color: colors.onSurfaceTertiary,
    letterSpacing: 1,
    textTransform: "uppercase",
    marginBottom: spacing.sm,
  },
  field: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    padding: spacing.md,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  value: { fontSize: 15, color: colors.onSurface },
  placeholder: { fontSize: 15, color: colors.muted },

  iosOverlay: {
    flex: 1,
    backgroundColor: "rgba(44,30,22,0.5)",
    justifyContent: "flex-end",
  },
  iosSheet: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    paddingBottom: spacing.xl,
  },
  iosHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  iosCancel: { color: colors.muted, fontSize: 15 },
  iosDone: { color: colors.brandPrimary, fontSize: 15, fontWeight: "600" },
  webTitle: { fontSize: 15, fontWeight: "600", color: colors.onSurface },
});

import React, { useEffect, useState, useRef } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  Modal,
  FlatList,
  ActivityIndicator,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { colors, spacing, radius, fonts } from "../theme";
import { getAllPlaces, searchPlaces, PlaceInfo, BirthDetails } from "../api";
import DateTimeField from "./DateTimeField";

interface Props {
  title: string;
  values: Partial<BirthDetails>;
  onChange: (patch: Partial<BirthDetails>) => void;
  testIDPrefix?: string;
}

export default function BirthForm({ title, values, onChange, testIDPrefix = "form" }: Props) {
  const [showPlaces, setShowPlaces] = useState(false);
  const [places, setPlaces] = useState<PlaceInfo[]>([]);
  const [filter, setFilter] = useState("");
  const [loading, setLoading] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Load defaults when opened
  useEffect(() => {
    if (showPlaces && places.length === 0 && !filter) {
      getAllPlaces().then(setPlaces).catch(() => {});
    }
  }, [showPlaces, places.length, filter]);

  // Debounced remote search as user types
  useEffect(() => {
    if (!showPlaces) return;
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!filter || filter.trim().length < 2) {
      // reset to default list
      if (!filter && places.length === 0) {
        getAllPlaces().then(setPlaces).catch(() => {});
      }
      return;
    }
    setLoading(true);
    debounceRef.current = setTimeout(async () => {
      try {
        const res = await searchPlaces(filter.trim());
        setPlaces(res);
      } catch {
        // ignore
      } finally {
        setLoading(false);
      }
    }, 450);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter, showPlaces]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title}</Text>

      <View style={styles.field}>
        <Text style={styles.label}>Name / नाम</Text>
        <TextInput
          testID={`${testIDPrefix}-name-input`}
          style={styles.input}
          value={values.name || ""}
          onChangeText={(t) => onChange({ name: t })}
          placeholder="Full name"
          placeholderTextColor={colors.muted}
        />
      </View>

      <View style={styles.row}>
        <View style={[styles.field, { flex: 1, marginRight: spacing.md }]}>
          <DateTimeField
            mode="date"
            label="Date / जन्म तिथि"
            value={values.date || ""}
            onChange={(v) => onChange({ date: v })}
            testID={`${testIDPrefix}-date-input`}
          />
        </View>
        <View style={[styles.field, { flex: 1 }]}>
          <DateTimeField
            mode="time"
            label="Time / जन्म समय"
            value={values.time || ""}
            onChange={(v) => onChange({ time: v })}
            testID={`${testIDPrefix}-time-input`}
          />
        </View>
      </View>

      <View style={styles.field}>
        <Text style={styles.label}>Place / जन्म स्थान</Text>
        <Pressable
          testID={`${testIDPrefix}-place-input`}
          onPress={() => setShowPlaces(true)}
          style={styles.placeButton}
        >
          <Text style={values.place ? styles.placeText : styles.placePlaceholder} numberOfLines={1}>
            {values.place || "Search city or village"}
          </Text>
          <Feather name="search" size={18} color={colors.muted} />
        </Pressable>
      </View>

      <Modal
        visible={showPlaces}
        animationType="slide"
        transparent
        onRequestClose={() => setShowPlaces(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Select Place</Text>
              <Pressable onPress={() => setShowPlaces(false)} testID={`${testIDPrefix}-place-close`}>
                <Feather name="x" size={22} color={colors.onSurface} />
              </Pressable>
            </View>
            <View style={styles.searchWrap}>
              <Feather name="search" size={16} color={colors.muted} style={styles.searchIcon} />
              <TextInput
                testID={`${testIDPrefix}-place-search`}
                style={styles.searchInput}
                value={filter}
                onChangeText={setFilter}
                placeholder="Type city or village name..."
                placeholderTextColor={colors.muted}
                autoFocus
              />
              {loading && <ActivityIndicator size="small" color={colors.brandPrimary} />}
            </View>
            <Text style={styles.hint}>
              Type at least 2 letters. Search covers Indian cities and villages via OpenStreetMap.
            </Text>
            <FlatList
              data={places}
              keyExtractor={(item, idx) => `${item.name}-${idx}`}
              keyboardShouldPersistTaps="handled"
              ListEmptyComponent={
                <Text style={styles.emptyText}>
                  {loading ? "Searching..." : filter ? "No places found" : "Loading..."}
                </Text>
              }
              renderItem={({ item }) => (
                <Pressable
                  testID={`place-item-${item.name}`}
                  style={styles.placeItem}
                  onPress={() => {
                    onChange({
                      place: item.name,
                      latitude: item.lat,
                      longitude: item.lon,
                      tz_offset: item.tz,
                    });
                    setShowPlaces(false);
                    setFilter("");
                  }}
                >
                  <Feather name="map-pin" size={14} color={colors.brandPrimary} />
                  <Text style={styles.placeItemText} numberOfLines={2}>{item.name}</Text>
                </Pressable>
              )}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.surfaceSecondary,
    padding: spacing.lg,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: spacing.lg,
  },
  title: {
    fontFamily: fonts.display,
    fontSize: 22,
    color: colors.onSurface,
    marginBottom: spacing.lg,
    fontWeight: "600",
  },
  field: {
    marginBottom: spacing.lg,
  },
  row: {
    flexDirection: "row",
  },
  label: {
    fontSize: 12,
    color: colors.onSurfaceTertiary,
    letterSpacing: 1,
    textTransform: "uppercase",
    marginBottom: spacing.sm,
  },
  input: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    padding: spacing.md,
    fontSize: 15,
    color: colors.onSurface,
  },
  placeButton: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    padding: spacing.md,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: spacing.sm,
  },
  placeText: {
    fontSize: 15,
    color: colors.onSurface,
    flex: 1,
  },
  placePlaceholder: {
    fontSize: 15,
    color: colors.muted,
    flex: 1,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(44,30,22,0.5)",
    justifyContent: "flex-end",
  },
  modalContent: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    padding: spacing.lg,
    height: "85%",
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: spacing.md,
  },
  modalTitle: {
    fontFamily: fonts.display,
    fontSize: 22,
    color: colors.onSurface,
    fontWeight: "600",
  },
  searchWrap: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    paddingHorizontal: spacing.md,
  },
  searchIcon: { marginRight: spacing.sm },
  searchInput: {
    flex: 1,
    padding: spacing.md,
    fontSize: 15,
    color: colors.onSurface,
  },
  hint: {
    fontSize: 11,
    color: colors.muted,
    marginTop: spacing.sm,
    marginBottom: spacing.md,
    fontStyle: "italic",
  },
  placeItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  placeItemText: {
    fontSize: 14,
    color: colors.onSurface,
    flex: 1,
  },
  emptyText: {
    textAlign: "center",
    color: colors.muted,
    padding: spacing.xl,
    fontStyle: "italic",
  },
});

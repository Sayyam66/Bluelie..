import React from "react";
import { View, Text, StyleSheet } from "react-native";
import Svg, { Line, Rect, G, Text as SvgText } from "react-native-svg";
import { colors, fonts } from "../theme";
import { HouseSign } from "../api";

interface Props {
  size?: number;
  houseSigns: HouseSign[];
}

const PLANET_SHORT: Record<string, string> = {
  Sun: "Su",
  Moon: "Mo",
  Mars: "Ma",
  Mercury: "Me",
  Jupiter: "Ju",
  Venus: "Ve",
  Saturn: "Sa",
  Rahu: "Ra",
  Ketu: "Ke",
};

const RASHI_NUM_IGNORED: Record<string, number> = {
  Aries: 1, Taurus: 2, Gemini: 3, Cancer: 4, Leo: 5, Virgo: 6,
  Libra: 7, Scorpio: 8, Sagittarius: 9, Capricorn: 10, Aquarius: 11, Pisces: 12,
};
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const _unused = RASHI_NUM_IGNORED;

/*
North Indian Kundli - diamond layout inside a square.
House positions (house index -> (cx, cy) fraction of size):
  1 (top center diamond top)
  2 (top-left corner triangle)
  3 (left triangle top-left)
  4 (left center diamond)
  5 (left triangle bottom-left)
  6 (bottom-left corner triangle)
  7 (bottom center diamond)
  8 (bottom-right corner triangle)
  9 (right triangle bottom-right)
  10 (right center diamond)
  11 (right triangle top-right)
  12 (top-right corner triangle)
*/
const HOUSE_POSITIONS: Record<number, { x: number; y: number }> = {
  1:  { x: 0.5,  y: 0.22 },
  2:  { x: 0.22, y: 0.1  },
  3:  { x: 0.1,  y: 0.22 },
  4:  { x: 0.22, y: 0.5  },
  5:  { x: 0.1,  y: 0.78 },
  6:  { x: 0.22, y: 0.9  },
  7:  { x: 0.5,  y: 0.78 },
  8:  { x: 0.78, y: 0.9  },
  9:  { x: 0.9,  y: 0.78 },
  10: { x: 0.78, y: 0.5  },
  11: { x: 0.9,  y: 0.22 },
  12: { x: 0.78, y: 0.1  },
};

// where to put the small sign number for each house
const SIGN_POSITIONS: Record<number, { x: number; y: number }> = {
  1:  { x: 0.5,  y: 0.32 },
  2:  { x: 0.28, y: 0.18 },
  3:  { x: 0.18, y: 0.28 },
  4:  { x: 0.3,  y: 0.5  },
  5:  { x: 0.18, y: 0.72 },
  6:  { x: 0.28, y: 0.82 },
  7:  { x: 0.5,  y: 0.68 },
  8:  { x: 0.72, y: 0.82 },
  9:  { x: 0.82, y: 0.72 },
  10: { x: 0.7,  y: 0.5  },
  11: { x: 0.82, y: 0.28 },
  12: { x: 0.72, y: 0.18 },
};

export default function KundliChart({ size = 320, houseSigns }: Props) {
  const s = size;

  return (
    <View style={[styles.container, { width: s, height: s }]}>
      <Svg width={s} height={s}>
        {/* Outer square */}
        <Rect
          x={1}
          y={1}
          width={s - 2}
          height={s - 2}
          stroke={colors.onSurface}
          strokeWidth={1.5}
          fill={colors.surfaceSecondary}
        />
        {/* Diagonals: corner to corner */}
        <Line x1={0} y1={0} x2={s} y2={s} stroke={colors.onSurface} strokeWidth={1} />
        <Line x1={s} y1={0} x2={0} y2={s} stroke={colors.onSurface} strokeWidth={1} />
        {/* Inner diamond: mid-side to mid-side */}
        <Line x1={s / 2} y1={0} x2={s} y2={s / 2} stroke={colors.onSurface} strokeWidth={1} />
        <Line x1={s} y1={s / 2} x2={s / 2} y2={s} stroke={colors.onSurface} strokeWidth={1} />
        <Line x1={s / 2} y1={s} x2={0} y2={s / 2} stroke={colors.onSurface} strokeWidth={1} />
        <Line x1={0} y1={s / 2} x2={s / 2} y2={0} stroke={colors.onSurface} strokeWidth={1} />

        {/* House sign numbers */}
        {houseSigns.map((h) => {
          const pos = SIGN_POSITIONS[h.house];
          if (!pos) return null;
          const signNum = h.sign_index + 1;
          return (
            <SvgText
              key={`sign-${h.house}`}
              x={pos.x * s}
              y={pos.y * s}
              fontSize={11}
              fill={colors.brandPrimary}
              textAnchor="middle"
              fontWeight="700"
            >
              {signNum}
            </SvgText>
          );
        })}

        {/* Planets inside each house */}
        {houseSigns.map((h) => {
          const pos = HOUSE_POSITIONS[h.house];
          if (!pos) return null;
          return (
            <G key={`house-${h.house}`}>
              {h.planets.map((p, idx) => (
                <SvgText
                  key={`p-${h.house}-${p}`}
                  x={pos.x * s}
                  y={pos.y * s + idx * 14}
                  fontSize={12}
                  fill={colors.onSurface}
                  textAnchor="middle"
                  fontWeight="600"
                >
                  {PLANET_SHORT[p] || p}
                </SvgText>
              ))}
            </G>
          );
        })}
      </Svg>
      <Text style={styles.caption}>North Indian Chart · Lagna House 1</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignSelf: "center",
  },
  caption: {
    fontFamily: fonts.display,
    fontSize: 12,
    color: colors.onSurfaceTertiary,
    textAlign: "center",
    marginTop: 8,
    fontStyle: "italic",
  },
});

export const colors = {
  surface: "#FAF8F5",
  onSurface: "#2C1E16",
  surfaceSecondary: "#FFFFFF",
  onSurfaceSecondary: "#2C1E16",
  surfaceTertiary: "#F2EAE1",
  onSurfaceTertiary: "#4A3B32",
  surfaceInverse: "#2C1E16",
  onSurfaceInverse: "#FAF8F5",
  brand: "#C65333",
  brandPrimary: "#C65333",
  onBrandPrimary: "#FFFFFF",
  brandSecondary: "#D4A373",
  onBrandSecondary: "#2C1E16",
  brandTertiary: "#F9EED9",
  onBrandTertiary: "#8E3D22",
  success: "#2D6A4F",
  warning: "#E07A5F",
  error: "#9B2226",
  border: "#E8D8C8",
  borderStrong: "#C65333",
  divider: "#E8D8C8",
  muted: "#8A7563",
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  xxxl: 48,
};

export const radius = {
  sm: 6,
  md: 12,
  lg: 20,
  pill: 999,
};

export const fonts = {
  display: "serif" as const,     // fallback serif; visually approximates Cormorant Garamond
  text: "System" as const,
};

export const IMAGES = {
  hero: "https://images.unsplash.com/photo-1637404230552-5ac6d76cb3a0?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMzV8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMGdvbGQlMjBzcGlyaXR1YWx8ZW58MHx8fHwxNzgzMDAyMDgzfDA&ixlib=rb-4.1.0&q=85",
  matching: "https://images.unsplash.com/photo-1654156577076-e0350ba86cc1?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA2MDV8MHwxfHNlYXJjaHwyfHxpbmRpYW4lMjB0cmFkaXRpb25hbCUyMG1hcnJpYWdlJTIwd2VkZGluZyUyMGJhY2tncm91bmR8ZW58MHx8fHwxNzgzMDAyMDc3fDA&ixlib=rb-4.1.0&q=85",
  mandala: "https://images.unsplash.com/photo-1664403489326-0591c36be436?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1Nzh8MHwxfHNlYXJjaHwxfHxtYW5kYWxhfGVufDB8fHx8MTc4MzAwMjA4M3ww&ixlib=rb-4.1.0&q=85",
};

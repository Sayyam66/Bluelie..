import React from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";
import { Image } from "expo-image";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors, spacing, radius, fonts, IMAGES } from "@/src/theme";

const SECTIONS = [
  {
    title: "Janam Kundali / जन्म कुंडली",
    body: "Your Vedic birth chart maps the sky at the exact moment you were born. It reveals your Lagna (rising sign), Rashi (moon sign), Nakshatra, and the position of nine grahas across twelve bhavas.",
  },
  {
    title: "Rashi & Nakshatra / राशि व नक्षत्र",
    body: "Twelve Rashis divide the zodiac into 30° arcs. Twenty-seven Nakshatras further split it into 13°20' segments, each governed by a deity and dasha lord.",
  },
  {
    title: "Ashtakoot Guna Milan / अष्टकूट",
    body: "An 8-fold compatibility system totalling 36 points. Varna, Vashya, Tara, Yoni, Graha Maitri, Gana, Bhakoot, and Nadi are compared. 18+ points is considered acceptable, 24+ is very good, 32+ is excellent.",
  },
  {
    title: "Method / गणना विधि",
    body: "Calculations use Lahiri Ayanamsa sidereal positions derived from the birth date, time, and place. Results are for guidance and educational purposes.",
  },
];

export default function AboutScreen() {
  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <Image source={IMAGES.mandala} style={styles.mandala} contentFit="cover" />
          <Text style={styles.kicker}>ABOUT</Text>
          <Text style={styles.title}>Bluelie</Text>
          <Text style={styles.sub}>
            A calm, editorial companion to your Vedic birth chart and marital compatibility.
          </Text>
        </View>

        {SECTIONS.map((s) => (
          <View key={s.title} style={styles.card}>
            <Text style={styles.cardTitle}>{s.title}</Text>
            <Text style={styles.cardBody}>{s.body}</Text>
          </View>
        ))}

        <Text style={styles.footer}>ॐ · Made with reverence for ancient jyotisha</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.surface },
  content: { padding: spacing.lg, paddingBottom: spacing.xxxl },
  header: {
    alignItems: "flex-start",
    marginBottom: spacing.xl,
  },
  mandala: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: spacing.lg,
  },
  kicker: {
    letterSpacing: 4,
    fontSize: 10,
    color: colors.brandPrimary,
    marginBottom: spacing.sm,
  },
  title: {
    fontFamily: fonts.display,
    fontSize: 40,
    color: colors.onSurface,
    fontWeight: "600",
    lineHeight: 44,
  },
  sub: {
    color: colors.onSurfaceTertiary,
    fontSize: 14,
    marginTop: spacing.md,
    maxWidth: 300,
  },
  card: {
    backgroundColor: colors.surfaceSecondary,
    padding: spacing.lg,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: spacing.md,
  },
  cardTitle: {
    fontFamily: fonts.display,
    fontSize: 18,
    color: colors.onSurface,
    fontWeight: "600",
    marginBottom: spacing.sm,
  },
  cardBody: {
    color: colors.onSurfaceTertiary,
    fontSize: 14,
    lineHeight: 22,
  },
  footer: {
    fontFamily: fonts.display,
    textAlign: "center",
    color: colors.brandPrimary,
    marginTop: spacing.xl,
    fontStyle: "italic",
  },
});

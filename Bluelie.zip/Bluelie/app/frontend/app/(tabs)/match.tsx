import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { colors, spacing, radius, fonts, IMAGES } from "@/src/theme";
import BirthForm from "@/src/components/BirthForm";
import { matchKundli, BirthDetails, MatchResponse } from "@/src/api";

const DEFAULT_PLACE = {
  place: "New Delhi, India",
  latitude: 28.6139,
  longitude: 77.2090,
  tz_offset: 5.5,
};

export default function MatchScreen() {
  const [boy, setBoy] = useState<Partial<BirthDetails>>({ name: "", date: "", time: "", ...DEFAULT_PLACE });
  const [girl, setGirl] = useState<Partial<BirthDetails>>({ name: "", date: "", time: "", ...DEFAULT_PLACE });
  const [result, setResult] = useState<MatchResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleMatch = async () => {
    setError(null);
    if (!boy.name || !boy.date || !boy.time || !girl.name || !girl.date || !girl.time) {
      setError("Please fill both partners' details");
      return;
    }
    setLoading(true);
    try {
      const res = await matchKundli(boy as BirthDetails, girl as BirthDetails);
      setResult(res);
    } catch (e: any) {
      setError(e.message || "Match failed");
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setResult(null);
    setError(null);
  };

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
          {/* Hero */}
          <View style={styles.hero}>
            <Image source={IMAGES.matching} style={styles.heroImage} contentFit="cover" />
            <LinearGradient
              colors={["transparent", "rgba(44,30,22,0.4)", "rgba(44,30,22,0.95)"]}
              style={styles.heroGradient}
            />
            <View style={styles.heroContent}>
              <Text style={styles.heroKicker}>BLUELIE</Text>
              <Text style={styles.heroTitle}>Guna{"\n"}Milan</Text>
              <Text style={styles.heroSub}>
                Compare two horoscopes across the eight sacred kootas for marital compatibility.
              </Text>
            </View>
          </View>

          {result ? (
            <MatchResult result={result} onReset={handleReset} />
          ) : (
            <View style={styles.formSection}>
              <BirthForm
                title="Boy's Details / वर"
                values={boy}
                onChange={(patch) => setBoy({ ...boy, ...patch })}
                testIDPrefix="boy"
              />
              <BirthForm
                title="Girl's Details / वधू"
                values={girl}
                onChange={(patch) => setGirl({ ...girl, ...patch })}
                testIDPrefix="girl"
              />

              {error && (
                <View style={styles.errorBox} testID="match-error">
                  <Feather name="alert-triangle" size={16} color={colors.error} />
                  <Text style={styles.errorText}>{error}</Text>
                </View>
              )}

              <Pressable
                testID="match-kundli-button"
                onPress={handleMatch}
                disabled={loading}
                style={({ pressed }) => [styles.primaryButton, pressed && { opacity: 0.85 }, loading && { opacity: 0.6 }]}
              >
                {loading ? (
                  <ActivityIndicator color={colors.onBrandPrimary} />
                ) : (
                  <Text style={styles.primaryButtonText}>Check Compatibility</Text>
                )}
              </Pressable>
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function MatchResult({ result, onReset }: { result: MatchResponse; onReset: () => void }) {
  const pct = result.percentage;
  const barColor = pct >= 66 ? colors.success : pct >= 45 ? colors.warning : colors.error;

  return (
    <View style={styles.resultSection} testID="match-result">
      <View style={styles.namesRow}>
        <View style={styles.nameCard}>
          <Text style={styles.namesLabel}>वर / Boy</Text>
          <Text style={styles.nameText}>{result.boy_name}</Text>
          <Text style={styles.nameMeta}>{result.boy_rashi} · {result.boy_nakshatra}</Text>
        </View>
        <View style={styles.heartIcon}>
          <Feather name="heart" size={22} color={colors.brandPrimary} />
        </View>
        <View style={styles.nameCard}>
          <Text style={styles.namesLabel}>वधू / Girl</Text>
          <Text style={styles.nameText}>{result.girl_name}</Text>
          <Text style={styles.nameMeta}>{result.girl_rashi} · {result.girl_nakshatra}</Text>
        </View>
      </View>

      {/* Score */}
      <View style={styles.scoreCard} testID="match-score">
        <Text style={styles.scoreLabel}>Ashtakoot Score</Text>
        <Text style={styles.scoreValue}>
          {result.total_score}
          <Text style={styles.scoreMax}> / {result.max_score}</Text>
        </Text>
        <View style={styles.progressTrack}>
          <View style={[styles.progressFill, { width: `${pct}%`, backgroundColor: barColor }]} />
        </View>
        <Text style={[styles.verdict, { color: barColor }]}>{result.verdict}</Text>
        <Text style={styles.verdictHi}>{result.verdict_hi}</Text>
      </View>

      {/* Kootas breakdown */}
      <Text style={styles.sectionTitle}>Eight Kootas</Text>
      <View style={styles.kootaContainer}>
        {result.koots.map((k) => {
          const kpct = (k.obtained / k.max_points) * 100;
          return (
            <View key={k.name} style={styles.kootaRow} testID={`koota-${k.name}`}>
              <View style={styles.kootaHeader}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.kootaName}>
                    {k.name} <Text style={styles.kootaHi}>· {k.name_hi}</Text>
                  </Text>
                  <Text style={styles.kootaDesc}>{k.description}</Text>
                </View>
                <Text style={styles.kootaScore}>
                  {k.obtained}<Text style={styles.kootaScoreMax}> / {k.max_points}</Text>
                </Text>
              </View>
              <View style={styles.kootaTrack}>
                <View style={[styles.kootaFill, { width: `${kpct}%` }]} />
              </View>
            </View>
          );
        })}
      </View>

      <Pressable style={styles.secondaryBtn} onPress={onReset} testID="reset-match-button">
        <Text style={styles.secondaryBtnText}>Match Another Couple</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.surface },
  scrollContent: { paddingBottom: spacing.xxxl },

  hero: {
    height: 260,
    position: "relative",
    marginBottom: spacing.xl,
  },
  heroImage: { ...StyleSheet.absoluteFillObject, width: "100%", height: "100%" },
  heroGradient: { ...StyleSheet.absoluteFillObject },
  heroContent: {
    position: "absolute",
    left: spacing.xl,
    right: spacing.xl,
    bottom: spacing.lg,
  },
  heroKicker: {
    color: colors.brandSecondary,
    letterSpacing: 3,
    fontSize: 11,
    textTransform: "uppercase",
    marginBottom: spacing.sm,
  },
  heroTitle: {
    fontFamily: fonts.display,
    color: colors.onSurfaceInverse,
    fontSize: 44,
    lineHeight: 48,
    fontWeight: "600",
  },
  heroSub: {
    color: colors.onSurfaceInverse,
    opacity: 0.85,
    fontSize: 14,
    marginTop: spacing.sm,
    maxWidth: 280,
  },

  formSection: { paddingHorizontal: spacing.lg },

  errorBox: {
    flexDirection: "row",
    alignItems: "center",
    padding: spacing.md,
    backgroundColor: "#F9EED9",
    borderRadius: radius.sm,
    marginBottom: spacing.md,
    gap: spacing.sm,
  },
  errorText: { color: colors.error, flex: 1 },

  primaryButton: {
    backgroundColor: colors.brandPrimary,
    padding: spacing.lg,
    borderRadius: radius.sm,
    alignItems: "center",
    marginBottom: spacing.md,
  },
  primaryButtonText: {
    color: colors.onBrandPrimary,
    fontSize: 15,
    fontWeight: "600",
    letterSpacing: 1,
    textTransform: "uppercase",
  },

  resultSection: { paddingHorizontal: spacing.lg },

  namesRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: spacing.xl,
    gap: spacing.md,
  },
  nameCard: {
    flex: 1,
    backgroundColor: colors.surfaceSecondary,
    padding: spacing.lg,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  namesLabel: {
    fontSize: 10,
    letterSpacing: 1.5,
    color: colors.onSurfaceTertiary,
    textTransform: "uppercase",
    marginBottom: spacing.xs,
  },
  nameText: {
    fontFamily: fonts.display,
    fontSize: 18,
    color: colors.onSurface,
    fontWeight: "600",
  },
  nameMeta: {
    fontSize: 11,
    color: colors.muted,
    marginTop: 2,
  },
  heartIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.brandPrimary,
    alignItems: "center",
    justifyContent: "center",
  },

  scoreCard: {
    backgroundColor: colors.surfaceInverse,
    padding: spacing.xl,
    borderRadius: radius.md,
    alignItems: "center",
    marginBottom: spacing.xl,
  },
  scoreLabel: {
    letterSpacing: 3,
    fontSize: 10,
    color: colors.brandSecondary,
    textTransform: "uppercase",
    marginBottom: spacing.md,
  },
  scoreValue: {
    fontFamily: fonts.display,
    fontSize: 64,
    color: colors.onSurfaceInverse,
    fontWeight: "600",
    lineHeight: 68,
  },
  scoreMax: {
    fontSize: 28,
    color: colors.brandSecondary,
  },
  progressTrack: {
    width: "100%",
    height: 6,
    backgroundColor: "rgba(250,248,245,0.15)",
    borderRadius: 3,
    marginTop: spacing.lg,
    overflow: "hidden",
  },
  progressFill: {
    height: "100%",
    borderRadius: 3,
  },
  verdict: {
    fontFamily: fonts.display,
    fontSize: 22,
    marginTop: spacing.lg,
    fontWeight: "600",
  },
  verdictHi: {
    fontSize: 14,
    color: colors.brandSecondary,
    marginTop: 2,
  },

  sectionTitle: {
    fontFamily: fonts.display,
    fontSize: 22,
    color: colors.onSurface,
    marginBottom: spacing.md,
    fontWeight: "600",
  },
  kootaContainer: {
    backgroundColor: colors.surfaceSecondary,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
  },
  kootaRow: {
    marginBottom: spacing.lg,
  },
  kootaHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: spacing.sm,
  },
  kootaName: {
    fontFamily: fonts.display,
    fontSize: 16,
    color: colors.onSurface,
    fontWeight: "600",
  },
  kootaHi: {
    color: colors.brandPrimary,
    fontSize: 14,
  },
  kootaDesc: {
    fontSize: 11,
    color: colors.muted,
    marginTop: 2,
  },
  kootaScore: {
    fontFamily: fonts.display,
    fontSize: 20,
    color: colors.onSurface,
    fontWeight: "600",
  },
  kootaScoreMax: {
    fontSize: 12,
    color: colors.muted,
  },
  kootaTrack: {
    height: 4,
    backgroundColor: colors.surfaceTertiary,
    borderRadius: 2,
    overflow: "hidden",
  },
  kootaFill: {
    height: "100%",
    backgroundColor: colors.brandPrimary,
    borderRadius: 2,
  },

  secondaryBtn: {
    marginTop: spacing.xl,
    padding: spacing.lg,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.brandPrimary,
    alignItems: "center",
  },
  secondaryBtnText: {
    color: colors.brandPrimary,
    fontWeight: "600",
    letterSpacing: 1,
    textTransform: "uppercase",
    fontSize: 13,
  },
});

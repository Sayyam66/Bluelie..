import React, { useState, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  StatusBar,
} from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { SafeAreaView } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { colors, spacing, radius, fonts, IMAGES } from "@/src/theme";
import BirthForm from "@/src/components/BirthForm";
import KundliChart from "@/src/components/KundliChart";
import { generateKundli, BirthDetails, KundliResponse } from "@/src/api";

export default function HomeScreen() {
  const [details, setDetails] = useState<Partial<BirthDetails>>({
    name: "",
    date: "",
    time: "",
    place: "New Delhi, India",
    latitude: 28.6139,
    longitude: 77.2090,
    tz_offset: 5.5,
  });
  const [kundli, setKundli] = useState<KundliResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<ScrollView>(null);

  const handleGenerate = async () => {
    setError(null);
    if (!details.name || !details.date || !details.time) {
      setError("कृपया सभी विवरण भरें / Please fill all details");
      return;
    }
    setLoading(true);
    try {
      const res = await generateKundli(details as BirthDetails);
      setKundli(res);
      // Scroll to result after render
      setTimeout(() => scrollRef.current?.scrollTo({ y: 240, animated: true }), 200);
    } catch (e: any) {
      setError(e.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setKundli(null);
    setError(null);
  };

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <StatusBar barStyle="light-content" />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          ref={scrollRef}
          style={styles.scroll}
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          {/* Hero */}
          <View style={styles.hero}>
            <Image source={IMAGES.hero} style={styles.heroImage} contentFit="cover" />
            <LinearGradient
              colors={["transparent", "rgba(44,30,22,0.4)", "rgba(44,30,22,0.95)"]}
              style={styles.heroGradient}
            />
            <View style={styles.heroContent}>
              <Text style={styles.heroKicker}>BLUELIE</Text>
              <Text style={styles.heroTitle}>Janam{"\n"}Kundali</Text>
              <Text style={styles.heroSub}>
                Discover your cosmic blueprint through ancient Vedic wisdom.
              </Text>
            </View>
          </View>

          {kundli ? (
            <KundliResult kundli={kundli} onReset={handleReset} />
          ) : (
            <View style={styles.formSection}>
              <BirthForm
                title="Birth Details"
                values={details}
                onChange={(patch) => setDetails({ ...details, ...patch })}
                testIDPrefix="home"
              />

              {error && (
                <View style={styles.errorBox} testID="home-error">
                  <Feather name="alert-triangle" size={16} color={colors.error} />
                  <Text style={styles.errorText}>{error}</Text>
                </View>
              )}

              <Pressable
                testID="generate-kundli-button"
                onPress={handleGenerate}
                disabled={loading}
                style={({ pressed }) => [
                  styles.primaryButton,
                  pressed && { opacity: 0.85 },
                  loading && { opacity: 0.6 },
                ]}
              >
                {loading ? (
                  <ActivityIndicator color={colors.onBrandPrimary} />
                ) : (
                  <Text style={styles.primaryButtonText}>Generate Kundli</Text>
                )}
              </Pressable>
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function KundliResult({ kundli, onReset }: { kundli: KundliResponse; onReset: () => void }) {
  return (
    <View style={styles.resultContainer} testID="kundli-result">
      <View style={styles.resultHeader}>
        <View>
          <Text style={styles.resultKicker}>Kundli of</Text>
          <Text style={styles.resultName}>{kundli.name}</Text>
          <Text style={styles.resultMeta}>
            {kundli.birth_datetime} · {kundli.place}
          </Text>
        </View>
        <Pressable onPress={onReset} testID="reset-kundli-button" style={styles.iconBtn}>
          <Feather name="refresh-cw" size={18} color={colors.brandPrimary} />
        </Pressable>
      </View>

      {/* Summary tiles */}
      <View style={styles.tilesRow}>
        <View style={styles.tile} testID="tile-lagna">
          <Text style={styles.tileLabel}>Lagna / लग्न</Text>
          <Text style={styles.tileValue}>{kundli.lagna}</Text>
          <Text style={styles.tileHi}>{kundli.lagna_hi}</Text>
          <Text style={styles.tileMeta}>Lord: {kundli.lagna_lord}</Text>
        </View>
        <View style={styles.tile} testID="tile-moon">
          <Text style={styles.tileLabel}>Rashi / राशि</Text>
          <Text style={styles.tileValue}>{kundli.moon_rashi}</Text>
          <Text style={styles.tileHi}>{kundli.moon_rashi_hi}</Text>
          <Text style={styles.tileMeta}>Nakshatra: {kundli.moon_nakshatra}</Text>
        </View>
      </View>

      <View style={styles.tilesRow}>
        <View style={styles.tile} testID="tile-sun">
          <Text style={styles.tileLabel}>Sun Sign / सूर्य</Text>
          <Text style={styles.tileValue}>{kundli.sun_rashi}</Text>
          <Text style={styles.tileHi}>{kundli.sun_rashi_hi}</Text>
        </View>
        <View style={styles.tile} testID="tile-nak">
          <Text style={styles.tileLabel}>Nakshatra / नक्षत्र</Text>
          <Text style={styles.tileValue}>{kundli.moon_nakshatra}</Text>
          <Text style={styles.tileHi}>{kundli.moon_nakshatra_hi}</Text>
          <Text style={styles.tileMeta}>Pada {kundli.moon_pada} · Lord: {kundli.nakshatra_lord}</Text>
        </View>
      </View>

      {/* Chart */}
      <Text style={styles.sectionTitle}>Birth Chart</Text>
      <View style={styles.chartWrap}>
        <KundliChart houseSigns={kundli.house_signs} size={320} />
      </View>

      {/* Planetary positions */}
      <Text style={styles.sectionTitle}>Planetary Positions</Text>
      <View style={styles.planetTable} testID="planet-table">
        <View style={[styles.planetRow, styles.planetHead]}>
          <Text style={[styles.planetCell, { flex: 1.2 }]}>Planet</Text>
          <Text style={[styles.planetCell, { flex: 1.2 }]}>Rashi</Text>
          <Text style={[styles.planetCell, { flex: 0.6, textAlign: "center" }]}>H</Text>
          <Text style={[styles.planetCell, { flex: 1.5 }]}>Nakshatra</Text>
        </View>
        {kundli.planets.map((p) => (
          <View key={p.name} style={styles.planetRow}>
            <Text style={[styles.planetCell, { flex: 1.2, fontWeight: "600" }]}>
              {p.name} <Text style={styles.planetHi}>({p.name_hi})</Text>
            </Text>
            <Text style={[styles.planetCell, { flex: 1.2 }]}>{p.rashi}</Text>
            <Text style={[styles.planetCell, { flex: 0.6, textAlign: "center" }]}>{p.house}</Text>
            <Text style={[styles.planetCell, { flex: 1.5 }]}>
              {p.nakshatra} <Text style={styles.planetHi}>· {p.pada}</Text>
            </Text>
          </View>
        ))}
      </View>

      <Pressable style={styles.secondaryBtn} onPress={onReset} testID="generate-another-button">
        <Text style={styles.secondaryBtnText}>Generate Another Kundli</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.surface },
  scroll: { flex: 1 },
  scrollContent: { paddingBottom: spacing.xxxl },

  hero: {
    height: 260,
    position: "relative",
    marginBottom: spacing.xl,
  },
  heroImage: {
    ...StyleSheet.absoluteFillObject,
    width: "100%",
    height: "100%",
  },
  heroGradient: {
    ...StyleSheet.absoluteFillObject,
  },
  heroContent: {
    position: "absolute",
    left: spacing.xl,
    right: spacing.xl,
    bottom: spacing.lg,
  },
  heroKicker: {
    color: colors.brandSecondary,
    letterSpacing: 3,
    fontSize: 11,
    textTransform: "uppercase",
    marginBottom: spacing.sm,
  },
  heroTitle: {
    fontFamily: fonts.display,
    color: colors.onSurfaceInverse,
    fontSize: 44,
    lineHeight: 48,
    fontWeight: "600",
  },
  heroSub: {
    color: colors.onSurfaceInverse,
    opacity: 0.85,
    fontSize: 14,
    marginTop: spacing.sm,
    maxWidth: 280,
  },

  formSection: {
    paddingHorizontal: spacing.lg,
  },

  errorBox: {
    flexDirection: "row",
    alignItems: "center",
    padding: spacing.md,
    backgroundColor: "#F9EED9",
    borderRadius: radius.sm,
    marginBottom: spacing.md,
    gap: spacing.sm,
  },
  errorText: {
    color: colors.error,
    flex: 1,
  },

  primaryButton: {
    backgroundColor: colors.brandPrimary,
    padding: spacing.lg,
    borderRadius: radius.sm,
    alignItems: "center",
    marginBottom: spacing.md,
  },
  primaryButtonText: {
    color: colors.onBrandPrimary,
    fontSize: 15,
    fontWeight: "600",
    letterSpacing: 1,
    textTransform: "uppercase",
  },

  // Result
  resultContainer: {
    paddingHorizontal: spacing.lg,
  },
  resultHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: spacing.lg,
  },
  resultKicker: {
    letterSpacing: 2,
    fontSize: 10,
    color: colors.onSurfaceTertiary,
    textTransform: "uppercase",
  },
  resultName: {
    fontFamily: fonts.display,
    fontSize: 28,
    color: colors.onSurface,
    fontWeight: "600",
  },
  resultMeta: {
    fontSize: 12,
    color: colors.muted,
    marginTop: 2,
  },
  iconBtn: {
    padding: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.pill,
  },
  tilesRow: {
    flexDirection: "row",
    gap: spacing.md,
    marginBottom: spacing.md,
  },
  tile: {
    flex: 1,
    backgroundColor: colors.surfaceSecondary,
    borderRadius: radius.md,
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
  },
  tileLabel: {
    fontSize: 10,
    letterSpacing: 1.5,
    color: colors.onSurfaceTertiary,
    textTransform: "uppercase",
    marginBottom: spacing.sm,
  },
  tileValue: {
    fontFamily: fonts.display,
    fontSize: 22,
    color: colors.onSurface,
    fontWeight: "600",
  },
  tileHi: {
    fontSize: 14,
    color: colors.brandPrimary,
    marginTop: 2,
  },
  tileMeta: {
    fontSize: 11,
    color: colors.muted,
    marginTop: spacing.sm,
  },

  sectionTitle: {
    fontFamily: fonts.display,
    fontSize: 20,
    color: colors.onSurface,
    marginTop: spacing.xl,
    marginBottom: spacing.md,
    fontWeight: "600",
  },
  chartWrap: {
    backgroundColor: colors.surfaceSecondary,
    borderRadius: radius.md,
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
  },
  planetTable: {
    backgroundColor: colors.surfaceSecondary,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: "hidden",
  },
  planetRow: {
    flexDirection: "row",
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
  },
  planetHead: {
    backgroundColor: colors.surfaceTertiary,
  },
  planetCell: {
    fontSize: 13,
    color: colors.onSurface,
  },
  planetHi: {
    fontSize: 11,
    color: colors.muted,
  },

  secondaryBtn: {
    marginTop: spacing.xl,
    padding: spacing.lg,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.brandPrimary,
    alignItems: "center",
  },
  secondaryBtnText: {
    color: colors.brandPrimary,
    fontWeight: "600",
    letterSpacing: 1,
    textTransform: "uppercase",
    fontSize: 13,
  },
});

"""Kundli backend API tests"""
import os
import pytest
import requests

BASE_URL = (os.environ.get("EXPO_PUBLIC_BACKEND_URL") or
            os.environ.get("EXPO_BACKEND_URL", "")).rstrip("/")


@pytest.fixture(scope="module")
def api():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


# ---------- Health ----------
class TestHealth:
    def test_root(self, api):
        r = api.get(f"{BASE_URL}/api/")
        assert r.status_code == 200
        data = r.json()
        assert data.get("status") == "ok"


# ---------- Places (BUG FIX #1) ----------
class TestPlaces:
    def test_default_list(self, api):
        r = api.get(f"{BASE_URL}/api/places")
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        assert len(data) >= 15
        assert all("name" in p and "lat" in p and "lon" in p and "tz" in p for p in data)

    def test_search_local_city(self, api):
        r = api.get(f"{BASE_URL}/api/places", params={"q": "Mumbai"})
        assert r.status_code == 200
        data = r.json()
        assert any("Mumbai" in p["name"] for p in data)

    @pytest.mark.parametrize("q", ["azamgarh", "barabanki", "sitapur", "jhansi"])
    def test_search_obscure_places(self, api, q):
        r = api.get(f"{BASE_URL}/api/places", params={"q": q})
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        # Should return at least one result matching query (case-insensitive)
        matches = [p for p in data if q.lower() in p["name"].lower()]
        assert len(matches) > 0, f"No matches for {q}: got {[p['name'] for p in data[:5]]}"
        p = matches[0]
        assert isinstance(p["lat"], (int, float))
        assert isinstance(p["lon"], (int, float))
        assert isinstance(p["tz"], (int, float))


# ---------- Kundli generate (BUG FIX #2) ----------
class TestKundliGenerate:
    payload = {
        "name": "Test User",
        "date": "1990-05-15",
        "time": "10:30",
        "latitude": 28.6139,
        "longitude": 77.2090,
        "tz_offset": 5.5,
        "place": "New Delhi, India",
    }

    def test_generate_success(self, api):
        r = api.post(f"{BASE_URL}/api/kundli/generate", json=self.payload)
        assert r.status_code == 200, r.text
        d = r.json()
        # structure
        for k in ("name", "birth_datetime", "place", "lagna", "lagna_hi", "lagna_lord",
                  "moon_rashi", "moon_nakshatra", "moon_pada", "nakshatra_lord",
                  "sun_rashi", "planets", "house_signs"):
            assert k in d, f"missing {k}"
        assert d["name"] == "Test User"
        assert len(d["planets"]) == 9
        assert len(d["house_signs"]) == 12
        planet_names = {p["name"] for p in d["planets"]}
        assert planet_names == {"Sun", "Moon", "Mars", "Mercury", "Jupiter",
                                 "Venus", "Saturn", "Rahu", "Ketu"}
        for p in d["planets"]:
            assert 1 <= p["house"] <= 12
            assert 1 <= p["pada"] <= 4
            assert p["rashi_hi"] and p["nakshatra_hi"]

    def test_generate_invalid_date(self, api):
        bad = dict(self.payload, date="bad-date")
        r = api.post(f"{BASE_URL}/api/kundli/generate", json=bad)
        assert r.status_code in (400, 422)

    # ---- BUG FIX: flexible date formats ----
    @pytest.mark.parametrize("date_str,expected_year", [
        ("10/11/2005", 2005),        # DD/MM/YYYY -> 10 Nov 2005
        ("1990-05-15", 1990),         # ISO
        ("15-05-1990", 1990),         # DD-MM-YYYY
        ("2005/11/10", 2005),         # YYYY/MM/DD
    ])
    def test_generate_flexible_dates(self, api, date_str, expected_year):
        p = dict(self.payload, date=date_str)
        r = api.post(f"{BASE_URL}/api/kundli/generate", json=p)
        assert r.status_code == 200, f"Failed for {date_str}: {r.status_code} {r.text}"
        d = r.json()
        assert d["birth_datetime"].startswith(date_str)
        # Sanity: planets/house_signs still present
        assert len(d["planets"]) == 9
        assert len(d["house_signs"]) == 12

    def test_generate_ddmmyyyy_original_bug(self, api):
        """Regression: user reported invalid literal for int() with '10/11/2005'."""
        p = dict(self.payload, date="10/11/2005", time="08:30")
        r = api.post(f"{BASE_URL}/api/kundli/generate", json=p)
        assert r.status_code == 200, r.text
        d = r.json()
        assert "invalid literal" not in str(d)
        assert d["lagna"] in ["Aries","Taurus","Gemini","Cancer","Leo","Virgo",
                              "Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"]

    def test_match_with_ddmmyyyy(self, api):
        """Match endpoint should also accept DD/MM/YYYY."""
        boy = {"name": "Ravi", "date": "10/11/2005", "time": "08:30",
               "latitude": 28.6139, "longitude": 77.2090, "tz_offset": 5.5,
               "place": "New Delhi, India"}
        girl = {"name": "Priya", "date": "15-05-1992", "time": "14:15",
                "latitude": 19.0760, "longitude": 72.8777, "tz_offset": 5.5,
                "place": "Mumbai, India"}
        r = api.post(f"{BASE_URL}/api/kundli/match", json={"boy": boy, "girl": girl})
        assert r.status_code == 200, r.text


# ---------- Kundli match ----------
class TestKundliMatch:
    def test_match_success(self, api):
        boy = {"name": "Ravi", "date": "1990-05-15", "time": "10:30",
               "latitude": 28.6139, "longitude": 77.2090, "tz_offset": 5.5,
               "place": "New Delhi, India"}
        girl = {"name": "Priya", "date": "1992-08-20", "time": "14:15",
                "latitude": 19.0760, "longitude": 72.8777, "tz_offset": 5.5,
                "place": "Mumbai, India"}
        r = requests.post(f"{BASE_URL}/api/kundli/match", json={"boy": boy, "girl": girl})
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["boy_name"] == "Ravi"
        assert d["girl_name"] == "Priya"
        assert d["max_score"] == 36
        assert 0 <= d["total_score"] <= 36
        assert 0 <= d["percentage"] <= 100
        assert d["verdict"] and d["verdict_hi"]
        assert len(d["koots"]) == 8
        expected_koots = {"Varna", "Vashya", "Tara", "Yoni", "Graha Maitri",
                           "Gana", "Bhakoot", "Nadi"}
        assert {k["name"] for k in d["koots"]} == expected_koots
        # obtained <= max_points for each
        for k in d["koots"]:
            assert k["obtained"] <= k["max_points"]

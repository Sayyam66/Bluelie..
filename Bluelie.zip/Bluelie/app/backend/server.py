from fastapi import FastAPI, APIRouter, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import math
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime, timezone

import httpx
import swisseph as swe


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Swiss Ephemeris - set sidereal mode to Lahiri (standard for Vedic astrology in India)
swe.set_sid_mode(swe.SIDM_LAHIRI)

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

app = FastAPI()
api_router = APIRouter(prefix="/api")

# ==================== Vedic Astrology Constants ====================

RASHIS_HI = ["मेष", "वृषभ", "मिथुन", "कर्क", "सिंह", "कन्या",
             "तुला", "वृश्चिक", "धनु", "मकर", "कुंभ", "मीन"]
RASHIS_EN = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
             "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"]
RASHI_LORD = ["Mars", "Venus", "Mercury", "Moon", "Sun", "Mercury",
              "Venus", "Mars", "Jupiter", "Saturn", "Saturn", "Jupiter"]

NAKSHATRAS_HI = ["अश्विनी", "भरणी", "कृत्तिका", "रोहिणी", "मृगशिरा", "आर्द्रा",
                 "पुनर्वसु", "पुष्य", "आश्लेषा", "मघा", "पूर्वा फाल्गुनी", "उत्तरा फाल्गुनी",
                 "हस्त", "चित्रा", "स्वाति", "विशाखा", "अनुराधा", "ज्येष्ठा",
                 "मूल", "पूर्वाषाढ़ा", "उत्तराषाढ़ा", "श्रवण", "धनिष्ठा", "शतभिषा",
                 "पूर्व भाद्रपद", "उत्तर भाद्रपद", "रेवती"]
NAKSHATRAS_EN = ["Ashwini", "Bharani", "Krittika", "Rohini", "Mrigashira", "Ardra",
                 "Punarvasu", "Pushya", "Ashlesha", "Magha", "Purva Phalguni", "Uttara Phalguni",
                 "Hasta", "Chitra", "Swati", "Vishakha", "Anuradha", "Jyeshtha",
                 "Mula", "Purva Ashadha", "Uttara Ashadha", "Shravana", "Dhanishta", "Shatabhisha",
                 "Purva Bhadrapada", "Uttara Bhadrapada", "Revati"]

# Nakshatra Lords (Vimshottari Dasha lords)
NAKSHATRA_LORDS = ["Ketu", "Venus", "Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn", "Mercury"] * 3

# Ashtakoot Varna, Vashya, Yoni, Gana, Nadi tables based on Nakshatra
VARNA = ["Brahmin", "Kshatriya", "Vaishya", "Shudra"]
# Nakshatra -> Yoni (14 yonis)
YONI_MAP = [1, 2, 3, 4, 5, 5, 6, 6, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 14, 1, 2, 3]
YONI_NAMES = ["Horse","Elephant","Sheep","Serpent","Dog","Cat","Rat","Cow","Buffalo","Tiger","Deer","Monkey","Mongoose","Lion"]

# Gana: Deva (0), Manushya (1), Rakshasa (2)
GANA_MAP = [0,2,1,1,0,1,0,0,2,2,1,1,0,0,0,2,0,2,2,1,1,0,2,2,1,1,0]

# Nadi: Adi (0), Madhya (1), Antya (2) - repeats every 3
NADI_SEQUENCE = [0,1,2,2,1,0,0,1,2,2,1,0,0,1,2,2,1,0,0,1,2,2,1,0,0,1,2]

# Yoni compatibility scores (14x14) - simplified using common table (max 4)
YONI_COMPAT = None  # computed below

# ==================== Astronomical Calculations (Swiss Ephemeris) ====================

# Swiss Ephemeris planet constants map
SWE_PLANETS = {
    "Sun":     swe.SUN,
    "Moon":    swe.MOON,
    "Mars":    swe.MARS,
    "Mercury": swe.MERCURY,
    "Jupiter": swe.JUPITER,
    "Venus":   swe.VENUS,
    "Saturn":  swe.SATURN,
    "Rahu":    swe.MEAN_NODE,     # Mean node = Rahu (standard in Vedic)
}
SIDEREAL_FLAG = swe.FLG_SIDEREAL | swe.FLG_SWIEPH | swe.FLG_SPEED

def julian_day(year, month, day, hour, minute, tz_offset):
    """Universal Time Julian Day via Swiss Ephemeris."""
    ut_hour = hour + minute / 60.0 - tz_offset
    return swe.julday(year, month, day, ut_hour)

def norm360(x):
    x = x % 360.0
    if x < 0:
        x += 360.0
    return x

def planet_sidereal_longitude(jd, planet_name):
    """Sidereal (Lahiri) ecliptic longitude and retrograde flag for a planet."""
    pid = SWE_PLANETS[planet_name]
    result, _ = swe.calc_ut(jd, pid, SIDEREAL_FLAG)
    lon = norm360(result[0])
    # result[3] = daily motion in longitude; negative => retrograde
    retro = result[3] < 0
    return lon, retro

def ascendant_sidereal(jd, latitude, longitude):
    """Sidereal (Lahiri) ascendant longitude via Swiss Ephemeris houses_ex."""
    cusps, ascmc = swe.houses_ex(jd, latitude, longitude, b'P', swe.FLG_SIDEREAL)
    return norm360(ascmc[0])

def get_rashi_index(sidereal_lon):
    return int(sidereal_lon // 30) % 12

def get_nakshatra_index(sidereal_lon):
    return int(sidereal_lon // (360.0/27)) % 27

def get_pada(sidereal_lon):
    naksh_span = 360.0/27  # 13.333
    within = sidereal_lon % naksh_span
    return int(within // (naksh_span/4)) + 1

def format_lon(lon):
    deg = int(lon)
    minutes = (lon - deg) * 60
    m = int(minutes)
    s = int((minutes - m) * 60)
    return f"{deg}° {m}' {s}\""

# ==================== Pydantic Models ====================

class BirthDetails(BaseModel):
    name: str
    date: str  # YYYY-MM-DD
    time: str  # HH:MM (24hr)
    latitude: float = 28.6139   # default: Delhi
    longitude: float = 77.2090
    tz_offset: float = 5.5      # default: IST
    place: Optional[str] = "New Delhi, India"

class PlanetPosition(BaseModel):
    name: str
    name_hi: str
    longitude: float
    longitude_formatted: str
    rashi: str
    rashi_hi: str
    house: int
    nakshatra: str
    nakshatra_hi: str
    pada: int
    retrograde: bool = False

class KundliResponse(BaseModel):
    name: str
    birth_datetime: str
    place: str
    lagna: str
    lagna_hi: str
    lagna_lord: str
    moon_rashi: str
    moon_rashi_hi: str
    moon_nakshatra: str
    moon_nakshatra_hi: str
    moon_pada: int
    nakshatra_lord: str
    sun_rashi: str
    sun_rashi_hi: str
    planets: List[PlanetPosition]
    house_signs: List[dict]  # 12 houses with sign and planets

class MatchInput(BaseModel):
    boy: BirthDetails
    girl: BirthDetails

class KootScore(BaseModel):
    name: str
    name_hi: str
    max_points: float
    obtained: float
    description: str

class MatchResponse(BaseModel):
    boy_name: str
    girl_name: str
    boy_rashi: str
    boy_nakshatra: str
    girl_rashi: str
    girl_nakshatra: str
    total_score: float
    max_score: float
    percentage: float
    verdict: str
    verdict_hi: str
    koots: List[KootScore]

# ==================== Kundli Logic ====================

PLANET_LIST = ["Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn","Rahu","Ketu"]
PLANET_HI = {"Sun":"सूर्य","Moon":"चंद्र","Mars":"मंगल","Mercury":"बुध","Jupiter":"गुरु",
             "Venus":"शुक्र","Saturn":"शनि","Rahu":"राहु","Ketu":"केतु"}

def compute_planet_positions(jd):
    """Returns dict of {planet: (sidereal_longitude, retrograde_bool)} using Swiss Ephemeris."""
    positions = {}
    for pname in ["Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn","Rahu"]:
        lon, retro = planet_sidereal_longitude(jd, pname)
        positions[pname] = (lon, retro)
    # Ketu is exactly 180° opposite Rahu
    rahu_lon, rahu_retro = positions["Rahu"]
    positions["Ketu"] = (norm360(rahu_lon + 180), rahu_retro)
    return positions

def parse_date_flexible(s: str):
    """Accept YYYY-MM-DD, DD/MM/YYYY, DD-MM-YYYY, MM/DD/YYYY (heuristic).
    Returns (year, month, day)."""
    s = s.strip()
    # Try ISO first
    for fmt in ("%Y-%m-%d", "%Y/%m/%d"):
        try:
            dt = datetime.strptime(s, fmt)
            return dt.year, dt.month, dt.day
        except ValueError:
            pass
    # Split by / or -
    import re
    parts = re.split(r"[/\-\.]", s)
    if len(parts) != 3:
        raise ValueError(f"Invalid date format: {s}. Use YYYY-MM-DD or DD/MM/YYYY")
    a, b, c = [int(p) for p in parts]
    # If first is 4-digit year
    if a > 31:
        return a, b, c
    # If last is 4-digit year -> DD/MM/YYYY (Indian convention)
    if c > 31:
        # Prefer DD/MM/YYYY
        if b <= 12 and a <= 31:
            return c, b, a
        # Fallback MM/DD/YYYY
        if a <= 12 and b <= 31:
            return c, a, b
        raise ValueError(f"Ambiguous date: {s}")
    raise ValueError(f"Invalid date: {s}")

def parse_time_flexible(s: str):
    """Accept HH:MM, HH:MM:SS, HH.MM, H:MM AM/PM. Returns (hour, minute)."""
    s = s.strip()
    import re
    ampm = None
    m = re.search(r"\b(AM|PM|am|pm)\b", s)
    if m:
        ampm = m.group(1).upper()
        s = s.replace(m.group(0), "").strip()
    parts = re.split(r"[:\.\-]", s)
    if len(parts) < 2:
        raise ValueError(f"Invalid time: {s}. Use HH:MM")
    hh = int(parts[0])
    mm = int(parts[1])
    if ampm == "PM" and hh < 12:
        hh += 12
    if ampm == "AM" and hh == 12:
        hh = 0
    if not (0 <= hh <= 23 and 0 <= mm <= 59):
        raise ValueError(f"Invalid time: {s}")
    return hh, mm

def build_kundli(details: BirthDetails) -> KundliResponse:
    y, m, d = parse_date_flexible(details.date)
    hh, mm = parse_time_flexible(details.time)
    jd = julian_day(y, m, d, hh, mm, details.tz_offset)

    planet_data = compute_planet_positions(jd)
    asc_sid = ascendant_sidereal(jd, details.latitude, details.longitude)
    lagna_idx = get_rashi_index(asc_sid)

    # 12 houses starting from lagna sign
    house_signs = []
    house_planets = {i: [] for i in range(1, 13)}

    planets_out = []
    for pname in PLANET_LIST:
        lon, retro = planet_data[pname]
        ridx = get_rashi_index(lon)
        nidx = get_nakshatra_index(lon)
        # House: how many signs from lagna
        house = ((ridx - lagna_idx) % 12) + 1
        house_planets[house].append(pname)
        planets_out.append(PlanetPosition(
            name=pname,
            name_hi=PLANET_HI[pname],
            longitude=round(lon, 4),
            longitude_formatted=format_lon(lon),
            rashi=RASHIS_EN[ridx],
            rashi_hi=RASHIS_HI[ridx],
            house=house,
            nakshatra=NAKSHATRAS_EN[nidx],
            nakshatra_hi=NAKSHATRAS_HI[nidx],
            pada=get_pada(lon),
            retrograde=retro,
        ))

    for h in range(12):
        sidx = (lagna_idx + h) % 12
        house_signs.append({
            "house": h + 1,
            "sign_index": sidx,
            "sign": RASHIS_EN[sidx],
            "sign_hi": RASHIS_HI[sidx],
            "planets": house_planets[h + 1],
        })

    moon_lon, _ = planet_data["Moon"]
    moon_rashi_idx = get_rashi_index(moon_lon)
    moon_nak_idx = get_nakshatra_index(moon_lon)
    sun_lon, _ = planet_data["Sun"]
    sun_rashi_idx = get_rashi_index(sun_lon)

    return KundliResponse(
        name=details.name,
        birth_datetime=f"{details.date} {details.time}",
        place=details.place or "",
        lagna=RASHIS_EN[lagna_idx],
        lagna_hi=RASHIS_HI[lagna_idx],
        lagna_lord=RASHI_LORD[lagna_idx],
        moon_rashi=RASHIS_EN[moon_rashi_idx],
        moon_rashi_hi=RASHIS_HI[moon_rashi_idx],
        moon_nakshatra=NAKSHATRAS_EN[moon_nak_idx],
        moon_nakshatra_hi=NAKSHATRAS_HI[moon_nak_idx],
        moon_pada=get_pada(moon_lon),
        nakshatra_lord=NAKSHATRA_LORDS[moon_nak_idx],
        sun_rashi=RASHIS_EN[sun_rashi_idx],
        sun_rashi_hi=RASHIS_HI[sun_rashi_idx],
        planets=planets_out,
        house_signs=house_signs,
    )

# ==================== Ashtakoot Guna Milan ====================

def varna_score(boy_rashi, girl_rashi):
    # Varna based on rashi: 0=Brahmin, 1=Kshatriya, 2=Vaishya, 3=Shudra
    varna_map = {3:0, 7:0, 11:0, 0:1, 4:1, 8:1, 1:2, 5:2, 9:2, 2:3, 6:3, 10:3}
    b = varna_map[boy_rashi]
    g = varna_map[girl_rashi]
    return 1.0 if b >= g else 0.0

def vashya_score(boy_rashi, girl_rashi):
    # Simplified vashya groups
    groups = {
        0:"Chatushpad", 1:"Chatushpad", 3:"Jalachar", 6:"Manav",
        2:"Manav", 5:"Manav", 4:"Vanachar", 7:"Keet",
        8:"Chatushpad", 9:"Jalachar", 10:"Manav", 11:"Jalachar"
    }
    b = groups[boy_rashi]
    g = groups[girl_rashi]
    if b == g:
        return 2.0
    friendly = {("Manav","Chatushpad"):1.0, ("Chatushpad","Manav"):1.0,
                ("Jalachar","Manav"):1.0}
    return friendly.get((b,g), 0.5)

def tara_score(boy_nak, girl_nak):
    # Count from girl's nakshatra to boy's, divide by 9; remainder
    diff1 = ((boy_nak - girl_nak) % 27) + 1
    diff2 = ((girl_nak - boy_nak) % 27) + 1
    r1 = diff1 % 9
    r2 = diff2 % 9
    good = {1,3,5,7,0}  # 0 means 9
    s1 = 1.5 if r1 in good else 0
    s2 = 1.5 if r2 in good else 0
    return s1 + s2

def yoni_score(boy_nak, girl_nak):
    b = YONI_MAP[boy_nak]
    g = YONI_MAP[girl_nak]
    if b == g:
        return 4.0
    # simplified: friendly if same parity
    if abs(b - g) <= 2:
        return 3.0
    if abs(b - g) <= 5:
        return 2.0
    if abs(b - g) <= 8:
        return 1.0
    return 0.0

def graha_maitri_score(boy_rashi, girl_rashi):
    lord_b = RASHI_LORD[boy_rashi]
    lord_g = RASHI_LORD[girl_rashi]
    friends = {
        "Sun":["Moon","Mars","Jupiter"],
        "Moon":["Sun","Mercury"],
        "Mars":["Sun","Moon","Jupiter"],
        "Mercury":["Sun","Venus"],
        "Jupiter":["Sun","Moon","Mars"],
        "Venus":["Mercury","Saturn"],
        "Saturn":["Mercury","Venus"],
    }
    if lord_b == lord_g:
        return 5.0
    if lord_g in friends.get(lord_b, []) and lord_b in friends.get(lord_g, []):
        return 5.0
    if lord_g in friends.get(lord_b, []) or lord_b in friends.get(lord_g, []):
        return 4.0
    return 1.0

def gana_score(boy_nak, girl_nak):
    b = GANA_MAP[boy_nak]
    g = GANA_MAP[girl_nak]
    if b == g:
        return 6.0
    if (b == 0 and g == 1) or (b == 1 and g == 0):
        return 5.0
    if (b == 1 and g == 2) or (b == 2 and g == 1):
        return 1.0
    return 0.0

def bhakoot_score(boy_rashi, girl_rashi):
    diff = abs(boy_rashi - girl_rashi)
    if diff in [1, 4, 6, 7, 8, 11]:
        return 0.0
    return 7.0

def nadi_score(boy_nak, girl_nak):
    b = NADI_SEQUENCE[boy_nak]
    g = NADI_SEQUENCE[girl_nak]
    return 0.0 if b == g else 8.0

def compute_match(boy: BirthDetails, girl: BirthDetails) -> MatchResponse:
    b_kundli = build_kundli(boy)
    g_kundli = build_kundli(girl)

    boy_rashi_idx = RASHIS_EN.index(b_kundli.moon_rashi)
    girl_rashi_idx = RASHIS_EN.index(g_kundli.moon_rashi)
    boy_nak_idx = NAKSHATRAS_EN.index(b_kundli.moon_nakshatra)
    girl_nak_idx = NAKSHATRAS_EN.index(g_kundli.moon_nakshatra)

    v = varna_score(boy_rashi_idx, girl_rashi_idx)
    va = vashya_score(boy_rashi_idx, girl_rashi_idx)
    t = tara_score(boy_nak_idx, girl_nak_idx)
    y = yoni_score(boy_nak_idx, girl_nak_idx)
    gm = graha_maitri_score(boy_rashi_idx, girl_rashi_idx)
    g = gana_score(boy_nak_idx, girl_nak_idx)
    bk = bhakoot_score(boy_rashi_idx, girl_rashi_idx)
    n = nadi_score(boy_nak_idx, girl_nak_idx)

    koots = [
        KootScore(name="Varna", name_hi="वर्ण", max_points=1, obtained=v,
                  description="Spiritual compatibility / ego balance"),
        KootScore(name="Vashya", name_hi="वश्य", max_points=2, obtained=va,
                  description="Mutual attraction and control"),
        KootScore(name="Tara", name_hi="तारा", max_points=3, obtained=t,
                  description="Health & wellbeing of the couple"),
        KootScore(name="Yoni", name_hi="योनि", max_points=4, obtained=y,
                  description="Physical & sexual compatibility"),
        KootScore(name="Graha Maitri", name_hi="ग्रह मैत्री", max_points=5, obtained=gm,
                  description="Mental & intellectual compatibility"),
        KootScore(name="Gana", name_hi="गण", max_points=6, obtained=g,
                  description="Temperament and behaviour"),
        KootScore(name="Bhakoot", name_hi="भकूट", max_points=7, obtained=bk,
                  description="Family welfare & prosperity"),
        KootScore(name="Nadi", name_hi="नाड़ी", max_points=8, obtained=n,
                  description="Health and progeny"),
    ]
    total = sum(k.obtained for k in koots)
    pct = total / 36 * 100

    if total >= 32:
        verdict = "Excellent Match"
        verdict_hi = "उत्तम मिलान"
    elif total >= 24:
        verdict = "Very Good Match"
        verdict_hi = "बहुत अच्छा मिलान"
    elif total >= 18:
        verdict = "Acceptable Match"
        verdict_hi = "स्वीकार्य मिलान"
    else:
        verdict = "Not Recommended"
        verdict_hi = "अनुशंसित नहीं"

    return MatchResponse(
        boy_name=boy.name,
        girl_name=girl.name,
        boy_rashi=b_kundli.moon_rashi,
        boy_nakshatra=b_kundli.moon_nakshatra,
        girl_rashi=g_kundli.moon_rashi,
        girl_nakshatra=g_kundli.moon_nakshatra,
        total_score=round(total, 1),
        max_score=36,
        percentage=round(pct, 1),
        verdict=verdict,
        verdict_hi=verdict_hi,
        koots=koots,
    )

# ==================== Places (offline sample) ====================

SAMPLE_PLACES = [
    {"name":"New Delhi, India","lat":28.6139,"lon":77.2090,"tz":5.5},
    {"name":"Mumbai, India","lat":19.0760,"lon":72.8777,"tz":5.5},
    {"name":"Kolkata, India","lat":22.5726,"lon":88.3639,"tz":5.5},
    {"name":"Chennai, India","lat":13.0827,"lon":80.2707,"tz":5.5},
    {"name":"Bengaluru, India","lat":12.9716,"lon":77.5946,"tz":5.5},
    {"name":"Hyderabad, India","lat":17.3850,"lon":78.4867,"tz":5.5},
    {"name":"Ahmedabad, India","lat":23.0225,"lon":72.5714,"tz":5.5},
    {"name":"Pune, India","lat":18.5204,"lon":73.8567,"tz":5.5},
    {"name":"Jaipur, India","lat":26.9124,"lon":75.7873,"tz":5.5},
    {"name":"Lucknow, India","lat":26.8467,"lon":80.9462,"tz":5.5},
    {"name":"Chandigarh, India","lat":30.7333,"lon":76.7794,"tz":5.5},
    {"name":"Patna, India","lat":25.5941,"lon":85.1376,"tz":5.5},
    {"name":"Bhopal, India","lat":23.2599,"lon":77.4126,"tz":5.5},
    {"name":"Varanasi, India","lat":25.3176,"lon":82.9739,"tz":5.5},
    {"name":"Amritsar, India","lat":31.6340,"lon":74.8723,"tz":5.5},
    {"name":"Surat, India","lat":21.1702,"lon":72.8311,"tz":5.5},
    {"name":"Kanpur, India","lat":26.4499,"lon":80.3319,"tz":5.5},
    {"name":"Nagpur, India","lat":21.1458,"lon":79.0882,"tz":5.5},
    {"name":"Indore, India","lat":22.7196,"lon":75.8577,"tz":5.5},
    {"name":"Kochi, India","lat":9.9312,"lon":76.2673,"tz":5.5},
]

# ==================== API Routes ====================

@api_router.get("/")
async def root():
    return {"message": "Kundli API", "status": "ok"}

@api_router.get("/limits")
async def get_limits():
    """Transparency endpoint: shows daily/monthly usage limits for free users.
    Since we use Swiss Ephemeris locally (offline, no 3rd-party API), the app is
    completely free and unlimited — no per-day or per-user cap."""
    return {
        "free_kundli_per_day": "unlimited",
        "free_match_per_day": "unlimited",
        "free_users_per_day": "unlimited",
        "total_daily_cap": None,
        "compute_engine": "Swiss Ephemeris (pyswisseph 2.10.3)",
        "ayanamsa": "Lahiri (SIDM_LAHIRI)",
        "accuracy": "Professional-grade — arc-second precision, same engine used by AstroSage, Jagannatha Hora, and other reference software",
        "cost_to_user": "Free forever",
        "requires_internet": False,
        "third_party_calls": "None for kundli calculation. Only place-search uses OpenStreetMap Photon (free, no key).",
        "notes_hi": "यह ऐप पूर्णतः निःशुल्क है। असीमित कुंडली बना सकते हैं। गणना Swiss Ephemeris से होती है — जो पेशेवर ज्योतिष सॉफ्टवेयर की मानक इंजन है।"
    }

@api_router.get("/places")
async def get_places(q: Optional[str] = None):
    """Search cities/villages. Uses OpenStreetMap Nominatim for free geocoding
    to cover all Indian cities and villages. Falls back to local sample list
    if network fails."""
    if not q or not q.strip():
        return SAMPLE_PLACES

    ql = q.strip()
    # First, check local list for offline fast results
    local = [p for p in SAMPLE_PLACES if ql.lower() in p["name"].lower()]

    # Then query Photon (OSM-based geocoder by Komoot) for broader coverage.
    # Free, no API key, covers Indian cities & villages.
    remote: List[dict] = []
    try:
        async with httpx.AsyncClient(timeout=6.0) as client_http:
            r = await client_http.get(
                "https://photon.komoot.io/api/",
                params={"q": ql, "limit": 15},
                headers={"User-Agent": "VedicAstroKundli/1.0"},
            )
            if r.status_code == 200:
                data = r.json()
                seen = set()
                for feat in data.get("features", []):
                    props = feat.get("properties", {})
                    geom = feat.get("geometry", {})
                    coords = geom.get("coordinates", [0, 0])
                    lon, lat = float(coords[0]), float(coords[1])
                    # Compact name
                    parts = []
                    for key in ("name",):
                        if props.get(key):
                            parts.append(props[key])
                    if props.get("state"):
                        parts.append(props["state"])
                    if props.get("country"):
                        parts.append(props["country"])
                    name = ", ".join(parts) if parts else props.get("name", "Unknown")
                    if name in seen:
                        continue
                    seen.add(name)
                    tz = 5.5 if (68 <= lon <= 97 and 6 <= lat <= 37) else round(lon / 15, 2)
                    remote.append({"name": name, "lat": lat, "lon": lon, "tz": tz})
    except Exception as e:
        logger.warning(f"Photon lookup failed: {e}")

    # Merge: local first, then remote (dedupe by name)
    seen_names = {p["name"] for p in local}
    merged = list(local)
    for p in remote:
        if p["name"] not in seen_names:
            merged.append(p)
            seen_names.add(p["name"])
    return merged if merged else SAMPLE_PLACES

@api_router.post("/kundli/generate", response_model=KundliResponse)
async def generate_kundli(details: BirthDetails):
    try:
        return build_kundli(details)
    except Exception as e:
        logger.exception("Kundli generation failed")
        raise HTTPException(status_code=400, detail=str(e))

@api_router.post("/kundli/match", response_model=MatchResponse)
async def match_kundli(payload: MatchInput):
    try:
        return compute_match(payload.boy, payload.girl)
    except Exception as e:
        logger.exception("Match failed")
        raise HTTPException(status_code=400, detail=str(e))

app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()

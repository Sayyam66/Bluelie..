# Bluelie — Play Store & App Store Submission Materials

Everything you need to submit Bluelie to Google Play Store and Apple App Store.

---

## 1. App Metadata

| Field | Value |
|-------|-------|
| **App name** | Bluelie |
| **Short description (80 chars)** | Vedic Kundli & Guna Milan — Janam Kundali and marriage compatibility. |
| **Package name (Android)** | com.emergent.birthchartapp.epnjb0 (defined in app.json — change if you own a domain) |
| **Bundle ID (iOS)** | com.emergent.birthchartapp.epnjb0 |
| **Version** | 1.0.0 |
| **Category (Play Store)** | Lifestyle |
| **Category (App Store)** | Lifestyle |
| **Content rating** | Everyone / 4+ |
| **Age target** | 13+ |
| **Pricing** | Free (no in-app purchases, no ads) |
| **Countries** | All (India-first, but content works globally) |

---

## 2. Store Descriptions

### Short description (Google Play — 80 char max)
> Vedic Kundli & Guna Milan — Janam Kundali and marriage compatibility.

### Full description (Google Play — 4000 char max)

> **Bluelie — Your calm companion to Vedic astrology.**
>
> Discover your Janam Kundali (Vedic birth chart) and check marital compatibility with the ancient Ashtakoot Guna Milan system — beautifully designed, easy to use, and quietly powerful.
>
> ✦ **Janam Kundali / जन्म कुंडली**
> Enter your birth date, time, and place, and Bluelie reveals your Lagna (rising sign), Rashi (moon sign), Nakshatra with Pada, and the precise position of all nine grahas — Sun, Moon, Mars, Mercury, Jupiter, Venus, Saturn, Rahu, and Ketu — across twelve bhavas. Your chart is drawn in the traditional North Indian style.
>
> ✦ **Guna Milan / अष्टकूट मिलान**
> Compare two horoscopes across the eight sacred kootas — Varna, Vashya, Tara, Yoni, Graha Maitri, Gana, Bhakoot, and Nadi — for a complete 36-point compatibility score with a clear verdict.
>
> ✦ **Bilingual — Hindi & English**
> Every rashi, nakshatra, and koota is shown in both Devanagari (Hindi) and English side by side.
>
> ✦ **Precise & Trusted Calculations**
> Bluelie uses the industry-standard Swiss Ephemeris with Lahiri ayanamsa — the same sidereal engine used by traditional Vedic astrologers.
>
> ✦ **City & Village Search**
> Look up any Indian city or village — from Mumbai to Azamgarh to your ancestral gaon — via built-in OpenStreetMap search.
>
> ✦ **Private by Design**
> No signup. No accounts. No ads. No tracking. Your birth details never leave the app for storage — they're used only to compute your chart and then discarded.
>
> **Perfect for:** anyone curious about their Vedic birth chart, families planning weddings and using traditional guna milan, students of jyotisha, and daily astrology enthusiasts.
>
> Downloading Bluelie is the first step to a calm, elegant conversation with the sky.

### App Store subtitle (30 char max)
> Vedic Kundli & Guna Milan

### App Store promotional text (170 char max)
> Beautiful, private Vedic astrology app — generate accurate Janam Kundali and Ashtakoot Guna Milan compatibility in Hindi and English.

---

## 3. Keywords (App Store, 100 char comma-separated)

`kundli,janam kundli,vedic astrology,rashi,nakshatra,guna milan,horoscope,jyotish,birth chart,ashtakoot`

---

## 4. Google Play — Data Safety Questionnaire

Answer these exactly as below when filling the **Data Safety** form:

### Data collection & security
- **Does your app collect or share any of the required user data types?** → **NO**
- **Is all user data encrypted in transit?** → **YES** (HTTPS)
- **Do you provide a way for users to request that their data be deleted?** → **YES** (we don't store data; uninstalling completes deletion)

### Data types collected
- **Personal info** → None
- **Financial info** → None
- **Health & fitness** → None
- **Messages** → None
- **Photos & videos** → None
- **Audio files** → None
- **Files & docs** → None
- **Calendar** → None
- **Contacts** → None
- **App activity** → None
- **Web browsing** → None
- **App info & performance** → None
- **Device or other IDs** → None

*Note: birth date/time/place is entered by the user on-device, sent to our server only to compute the chart, and never persisted. Under Play's definitions this is "ephemeral processing" and does not require disclosure. If Play asks about "sensitive personal info", you may optionally list **"Approximate location (city-level, from user typing)"** with purpose = "App functionality" and retention = "Not stored".*

---

## 5. Google Play — Content Rating (IARC)

Answer these on the IARC questionnaire:

| Question | Answer |
|----------|--------|
| Does your app contain violence? | **No** |
| Sexual content or nudity? | **No** |
| Profanity? | **No** |
| Controlled substances (drugs/alcohol/tobacco)? | **No** |
| Simulated gambling? | **No** |
| User-generated content / social features? | **No** |
| Users can interact with each other? | **No** |
| Shares user location? | **No** |
| Allows purchase of digital goods? | **No** |
| Digital purchases with real money? | **No** |

**Expected rating:** Everyone / PEGI 3 / USK 0 / 4+

---

## 6. Google Play — App Content Section

| Section | Answer |
|---------|--------|
| Target audience & content | **13 years old and above** (Lifestyle app) |
| Ads | **No, my app does not contain ads** |
| App access | **All functionality available without special access** |
| Content guidelines | Complies |
| US export laws | Complies |
| COVID-19 tracing/status app | **No** |
| Data safety | See section 4 above |
| Government app | **No** |
| News app | **No** |
| Financial features | **No** |
| Health features | **No** (astrology is not medical/health) |
| Actions | No shortcuts |

---

## 7. Apple App Store — App Privacy Questionnaire

Answer these in App Store Connect → App Privacy:

- **Data used to track you** → **No, we do not track**
- **Data linked to you** → **No data linked**
- **Data not linked to you** → **No data collected**

For each of the following categories, select **"Not Collected"**:
Contact Info, Health & Fitness, Financial Info, Location, Sensitive Info, Contacts, User Content, Browsing History, Search History, Identifiers, Purchases, Usage Data, Diagnostics, Other.

**Rationale statement (if asked):** *Birth details are processed transiently on our backend to compute the astrological chart and are never stored, logged, or linked to the user.*

---

## 8. Apple App Store — Age Rating

| Frequent/Intense | Answer |
|------------------|--------|
| Cartoon/Fantasy Violence | None |
| Realistic Violence | None |
| Sexual Content or Nudity | None |
| Profanity | None |
| Alcohol, Tobacco, Drug Use | None |
| Mature/Suggestive Themes | None |
| Simulated Gambling | None |
| Horror/Fear Themes | None |
| Medical/Treatment Info | None |
| Unrestricted Web Access | No |

**Expected rating:** 4+

---

## 9. Required URLs

| Purpose | URL |
|---------|-----|
| Privacy Policy | Host `/app/store_assets/PRIVACY_POLICY.md` on your website, e.g. `https://bluelie.app/privacy` |
| Support / Contact | `support@bluelie.app` or a landing page |
| Marketing (optional) | `https://bluelie.app` |

**You MUST host the privacy policy at a publicly reachable HTTPS URL before submitting — both Play Store and App Store enforce this.**

---

## 10. Screenshots

Included in this folder (`/app/store_assets/`):

- `screenshot_1_home.png` — Home screen with hero + birth details form
- `screenshot_2_kundli_result.png` — Generated Kundli summary tiles
- `screenshot_3_chart.png` — North Indian birth chart with planetary positions
- `screenshot_4_match.png` — Guna Milan compatibility screen

**Store requirements:**
- Play Store: minimum 2, maximum 8 phone screenshots; 320-3840px each side, 16:9 or 9:16
- App Store: 3 screenshots per device size (6.7", 6.5", 5.5")

Resize/reformat before upload using any image editor or `sips` on macOS. The four PNGs above satisfy the minimum for both stores.

---

## 11. App Icon

Included as `/app/frontend/assets/images/icon.png` (1024×1024). Also copied to `adaptive-icon.png`, `splash-image.png`, and `favicon.png` for use inside the Expo build.

**Play Store expects:** 512×512 PNG (32-bit with alpha) — resize `icon.png` to 512×512.
**App Store expects:** 1024×1024 PNG (opaque, no alpha) — use as-is.

---

## 12. Building the App Bundle (.aab)

Bluelie cannot generate the `.aab` file directly from the Emergent preview environment. Use one of these paths:

### Option A — Emergent Publish (recommended)
1. Click the **Publish** button in the top-right of the Emergent editor.
2. Choose "Android build" → provide your keystore (or let Emergent generate one).
3. Emergent runs the cloud EAS build and gives you a downloadable `.aab`.

### Option B — Save to GitHub → local EAS
1. Click **Save to GitHub** in Emergent.
2. Clone the repo locally.
3. Install EAS CLI: `npm install -g eas-cli`
4. Log in: `eas login`
5. Configure: `eas build:configure` (already partly done via `app.json`)
6. Build: `eas build --platform android --profile production`
7. When prompted, provide/generate a keystore.
8. Download the produced `.aab` from the Expo dashboard.

### For iOS `.ipa`
Same flow, use `--platform ios`, and provide your Apple Developer account credentials.

---

## 13. Submission Checklist

Use this before hitting **Submit for review**:

- [ ] Change package/bundle ID from `com.emergent.birthchartapp.epnjb0` to your own domain-based ID (e.g. `com.bluelie.app`)
- [ ] Host Privacy Policy at an HTTPS URL and put that URL in the store listing
- [ ] Set support email/URL
- [ ] Upload the 1024 icon and the 512 icon
- [ ] Upload at least 2 (Play) or 3 (App Store) phone screenshots
- [ ] Fill Data Safety / App Privacy per sections 4 and 7 above
- [ ] Fill Content Rating / Age Rating per sections 5 and 8 above
- [ ] Complete "App Content" section per section 6 above
- [ ] Generate `.aab` (Android) and/or `.ipa` (iOS) via Publish or EAS
- [ ] Upload to Play Console / App Store Connect
- [ ] Submit for review

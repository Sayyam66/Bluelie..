# Privacy Policy — Bluelie

**Effective date:** February 4, 2026
**Last updated:** February 4, 2026

Bluelie ("we", "our", "the app") is a Vedic astrology application that generates Janam Kundali (birth charts) and performs Ashtakoot Guna Milan (marital compatibility) analysis. This Privacy Policy explains what data we collect, how we use it, and your rights.

---

## 1. Data We Collect

### 1.1 Data You Provide
When you use Bluelie to generate a kundli or run a compatibility match, you enter the following on-device:

- **Name** (used for display only; can be any nickname)
- **Date of birth**
- **Time of birth**
- **Place of birth** (city / village name; used to determine latitude, longitude, and time zone)

For Guna Milan you also enter the same fields for a second person (with their consent).

### 1.2 Data We Do NOT Collect
- No email address, phone number, or password (Bluelie has no user accounts)
- No payment or financial information
- No location tracking, device sensors (camera, microphone, contacts, GPS), or biometrics
- No advertising identifiers, cookies, analytics fingerprints, or behavioral tracking
- No photos, files, or media from your device

### 1.3 Data We Do NOT Store
Birth details you enter are used **only during your active session** to compute the chart. They are:
- Held transiently in the app's memory while you view the result
- **Never persisted** to any Bluelie server or database
- **Never linked** to your device or identity
- Cleared automatically when you tap "Generate Another Kundli" or close the app

---

## 2. How We Use Your Data

Bluelie processes your birth details **solely** for the following purposes:

1. Sending the birth details to our backend server (`/api/kundli/generate` or `/api/kundli/match`) to run the astronomical calculation
2. Returning the calculated Kundli/Match report to your device for display
3. Immediately discarding the input after the response is sent — no server-side logging of birth details

All calculations are performed using the open-source Swiss Ephemeris library running on our own servers. No third-party astrology service is called.

---

## 3. Third-Party Services

We use one third-party service, and only for a limited purpose:

| Service | Purpose | Data Shared |
|---------|---------|-------------|
| **OpenStreetMap Photon** (photon.komoot.io) | Look up latitude/longitude/timezone for cities and villages you search | Only the city name you type in the "Place" search field |

Photon does not require, and we do not send, any personal identifier. Photon's privacy policy: https://photon.komoot.io/

No advertising SDKs, analytics SDKs, crash-reporting SDKs, or social login SDKs are integrated into Bluelie.

---

## 4. Data Sharing & Selling

**We do not sell, rent, share, or trade any user data with anyone, for any purpose.**

We do not disclose data to law enforcement or government agencies except when required by a valid legal process; in such cases, we would only be able to provide the information we hold — which, for Bluelie, is nothing.

---

## 5. Data Security

Bluelie's design minimises the attack surface:

- Communication between the app and our server uses HTTPS/TLS encryption
- Our server does not retain birth details after a response is sent
- No database of user records exists to breach

---

## 6. Children's Privacy

Bluelie is a general-audience astrology app. We do not knowingly collect personal information from children under the age of 13 (or 16 in the EU). Parents/guardians may enter a child's birth details to generate a kundli; this data is treated exactly the same as any other input and is never stored.

---

## 7. Your Rights

Because we do not store your data, there is generally nothing to access, correct, or delete. However, you may:

- Stop using the app at any time
- Uninstall the app to remove any locally cached preferences
- Contact us with any privacy question (see Section 10)

Users in the EU/UK have rights under **GDPR** (Articles 15–22). Users in California have rights under **CCPA**. We honor these rights on the same basis.

---

## 8. International Users

Bluelie is available worldwide. By using the app, you consent to the transient processing of your inputs on our servers as described in this policy.

---

## 9. Changes to This Policy

We may update this policy from time to time. Material changes will be highlighted inside the app before they take effect. The "Last updated" date at the top always reflects the current version.

---

## 10. Contact

Questions or concerns about privacy? Reach us at:

**Email:** privacy@bluelie.app
**Response time:** within 7 business days

---

## Summary in Plain Language

- We ask for your birth details **only when you generate a kundli**.
- We use them **only to compute the chart**.
- We **do not save them anywhere** after the chart is shown.
- We **do not have accounts, ads, tracking, or sharing** — there is nothing to sell.
- The only outside service we call is OpenStreetMap for city lookup, and we send it only the city name.

**Bluelie is designed to be a private, offline-feeling astrology companion. Your karmic blueprint stays yours.**

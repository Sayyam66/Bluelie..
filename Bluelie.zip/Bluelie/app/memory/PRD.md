# VedicAstro Kundli — Product Requirements

## Overview
Mobile app (React Native / Expo Router) that generates a Vedic Janam Kundali and performs Ashtakoot Guna Milan compatibility matching using **Swiss Ephemeris (pyswisseph 2.10.3)** — professional-grade accuracy with Lahiri ayanamsa. Hindi + English. **Free & unlimited** for all users, no signup, no cap, no ads.

## Features
- **Home tab (/):** Enter birth details (name, date, time, place). Generates Kundli showing Lagna, Rashi, Nakshatra, Sun sign, all 9 planetary positions with houses and retrograde flags, plus a North-Indian style birth chart drawn with SVG.
- **Match tab (/match):** Ashtakoot Guna Milan — enter two partners' birth details, returns 8 Kootas (Varna, Vashya, Tara, Yoni, Graha Maitri, Gana, Bhakoot, Nadi) with individual scores out of 36 and verdict.
- **About tab (/about):** Educational content + transparency section on engine and privacy.
- **Place search:** Live search over Indian cities and villages via Photon (OpenStreetMap) — free, no API key.
- **Flexible dates:** Accepts YYYY-MM-DD, DD/MM/YYYY, DD-MM-YYYY, and 12-hour times with AM/PM.
- **Transparency endpoint:** GET /api/limits documents unlimited free usage.

## Compute Engine
- **pyswisseph 2.10.3** — Swiss Ephemeris (same engine as AstroSage, Jagannatha Hora)
- Ayanamsa: **Lahiri** (`SIDM_LAHIRI`) — India's standard
- Sidereal flag: `FLG_SIDEREAL | FLG_SWIEPH | FLG_SPEED` (speed flag critical for retrograde detection)
- Rahu = mean node; Ketu = Rahu + 180°
- Houses: Placidus system for ascendant (`swe.houses_ex`)

## Accuracy notes
- Sidereal Lahiri ephemeris results may differ from popular / reconstructed birth charts for historical figures whose exact birth time is disputed. The engine output is astronomically correct.

## No auth · No push notifications · No 3rd-party astrology APIs.

# Test Credentials

No authentication required in this app. All features (Kundli generation and Guna Milan matching) are accessible directly without login.
